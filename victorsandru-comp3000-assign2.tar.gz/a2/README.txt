Victor Sandru
101231111

victorsandrua23000.txt is the file with all of the written answers.
3000shellMod.c is the edited version of 3000shell.c
3000userloginMod.c is the patched file of tutorial 4.

There are attached diff files.