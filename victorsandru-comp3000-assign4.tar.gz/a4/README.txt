Victor Sandru
101231111

ans.txt is the file with all of the written answers.
ones.c is the edited version of onesOriginal.c question 1

There are attached diff files.