Victor Sandru
101231111

victorsandrua33000.txt is the file with all of the written answers.
3000test-0.c is the edited version of 3000test.c question 2
3000test-a.c is the edited version of 3000test.c question 6

There are attached diff files.