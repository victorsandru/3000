Victor Sandru
101231111

victorsandrua13000 is the file with all of the written answers.
3000memviewChanged.c is the edited version of 3000memview.c with the answers commented out.